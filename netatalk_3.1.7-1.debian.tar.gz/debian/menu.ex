?package(netatalk):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="netatalk" command="/usr/bin/netatalk"
